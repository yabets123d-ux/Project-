document.addEventListener('DOMContentLoaded', () => {
    const jokeSetup = document.getElementById('joke-setup');
    const jokeDelivery = document.getElementById('joke-delivery');
    const punchlineBtn = document.getElementById('punchline-btn');
    const newJokeBtn = document.getElementById('new-joke-btn');
    const saveJokeBtn = document.getElementById('save-joke-btn');
    const jokeError = document.getElementById('joke-error');
    const jokeLoading = document.getElementById('joke-loading');

    const favoriteList = document.getElementById('favorite-list');
    const favoritesEmpty = document.getElementById('favorites-empty');
    const shuffleFavBtn = document.getElementById('shuffle-fav-btn');

    let currentJoke = null;
    let savedJokes = JSON.parse(localStorage.getItem('savedProgrammingJokes')) || [];

    // Function to fetch a new programming joke
    async function fetchNewJoke() {
        jokeSetup.textContent = '';
        jokeDelivery.classList.add('hidden');
        punchlineBtn.classList.add('hidden');
        jokeError.classList.add('hidden');
        jokeLoading.classList.remove('hidden');
        saveJokeBtn.disabled = true; // Disable save until joke is ready
        currentJoke = null; // Reset current joke

        try {
            const response = await fetch('https://v2.jokeapi.dev/joke/Programming');
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const data = await response.json();

            if (data.error) {
                throw new Error(data.message);
            }

            currentJoke = {
                setup: data.setup,
                delivery: data.delivery,
                id: data.id // Use joke ID for unique identification
            };

            jokeSetup.textContent = currentJoke.setup;
            punchlineBtn.classList.remove('hidden');
            saveJokeBtn.disabled = false;

        } catch (error) {
            console.error('Error fetching joke:', error);
            jokeError.textContent = 'Failed to fetch a joke. Please try again.';
            jokeError.classList.remove('hidden');
            saveJokeBtn.disabled = true;
        } finally {
            jokeLoading.classList.add('hidden');
        }
    }

    // Function to display punchline
    function showPunchline() {
        if (currentJoke && currentJoke.delivery ) {
            jokeDelivery.textContent = currentJoke.delivery;
            jokeDelivery.classList.remove('hidden');
            punchlineBtn.classList.add('hidden');
        }
    }

    // Function to render saved jokes
    function renderSavedJokes(jokesToRender = savedJokes) {
        favoriteList.innerHTML = '';
        favoritesEmpty.classList.add('hidden');
        shuffleFavBtn.disabled = jokesToRender.length <= 1; // Disable shuffle if 0 or 1 joke

        if (jokesToRender.length === 0) {
            favoritesEmpty.classList.remove('hidden');
            return;
        }

        jokesToRender.forEach(joke => {
            const listItem = document.createElement('li');
            listItem.classList.add('favorite-item');
            listItem.innerHTML = `
                <p class="joke-text"><strong>Setup:</strong> ${joke.setup}</p>
                <p class="joke-text"><strong>Punchline:</strong> ${joke.delivery}</p>
                <button class="remove-fav-btn" data-id="${joke.id}">Remove</button>
            `;
            favoriteList.appendChild(listItem);
        });
    }

    // Event listener for New Random Joke button
    newJokeBtn.addEventListener('click', fetchNewJoke);

    // Event listener for Show Punchline button
    punchlineBtn.addEventListener('click', showPunchline);

    // Event listener for Save Joke button
    saveJokeBtn.addEventListener('click', () => {
        if (currentJoke && currentJoke.setup && currentJoke.delivery) {
            // Check if joke already exists to prevent duplicates
            if (!savedJokes.some(j => j.id === currentJoke.id)) {
                savedJokes.push(currentJoke);
                localStorage.setItem('savedProgrammingJokes', JSON.stringify(savedJokes));
                renderSavedJokes();
                alert('Joke saved!');
            } else {
                alert('This joke is already saved!');
            }
        } else {
            alert('Please fetch a complete joke before saving.');
        }
    });

    // Event listener for removing a saved joke
    favoriteList.addEventListener('click', (event) => {
        if (event.target.classList.contains('remove-fav-btn')) {
            const idToRemove = parseInt(event.target.dataset.id);
            savedJokes = savedJokes.filter(joke => joke.id !== idToRemove);
            localStorage.setItem('savedProgrammingJokes', JSON.stringify(savedJokes));
            renderSavedJokes();
        }
    });

    // Event listener for Shuffle Favorites button
    shuffleFavBtn.addEventListener('click', () => {
        if (savedJokes.length > 1) {
            // Fisher-Yates (Knuth) shuffle algorithm
            for (let i = savedJokes.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [savedJokes[i], savedJokes[j]] = [savedJokes[j], savedJokes[i]]; // Swap elements
            }
            renderSavedJokes();
        } else {
            alert('You need at least two saved jokes to shuffle!');
        }
    });

    // Initial load
    fetchNewJoke();
    renderSavedJokes();
});